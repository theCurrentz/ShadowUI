
g_clubIdToSeenApplicants = {
}
