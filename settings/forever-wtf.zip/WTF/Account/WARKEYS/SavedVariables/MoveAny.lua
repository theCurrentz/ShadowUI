
MATAB = {
["minimapPos"] = 0,
["VERSION"] = 2,
["SHAREDSETTINGS"] = {
["D4MMBTNALWAYSSHOW"] = 0,
},
["MoveAny"] = {
},
["PROFILES"] = {
["DEFAULT"] = {
["ELES"] = {
["POINTS"] = {
["ExpansionLandingPageMinimapButton"] = {
},
["MALock"] = {
},
},
["SIZES"] = {
},
["OPTIONS"] = {
["SHOWMINIMAPBUTTON"] = {
["ENABLED"] = false,
},
["GAMETOOLTIP"] = {
["ENABLED"] = false,
},
["MINIMAP"] = {
["ENABLED"] = false,
},
["LOSSOFCONTROLFRAME"] = {
["ENABLED"] = false,
},
["TIMERTRACKER1"] = {
["ENABLED"] = false,
},
["BONUSROLLFRAME"] = {
["ENABLED"] = false,
},
["RAIDBOSSEMOTEFRAME"] = {
["ENABLED"] = false,
},
["ARCHEOLOGYDIGSITEPROGRESSBAR"] = {
["ENABLED"] = false,
},
["MICROMENU"] = {
["ENABLED"] = false,
},
["PLAYERFRAMEGROUPINDICATOR"] = {
["ENABLED"] = false,
},
["BAGS"] = {
["ENABLED"] = false,
},
["TARGETFRAMESPELLBAR"] = {
["ENABLED"] = false,
},
["DURABILITY"] = {
["ENABLED"] = false,
},
["VEHICLESEATINDICATOR"] = {
["ENABLED"] = false,
},
["FOCUSFRAMEBUFFMOVER"] = {
["ENABLED"] = false,
},
["UIWIDGETTOPCENTER"] = {
["ENABLED"] = false,
},
["TALKINGHEAD"] = {
["ENABLED"] = false,
},
["TARGETFRAMENAMEBACKGROUND"] = {
["ENABLED"] = false,
},
["CASTINGBARTIMER"] = {
["ENABLED"] = false,
},
["BOSSTARGETFRAMECONTAINER"] = {
["ENABLED"] = false,
},
["SCALEFRAMES"] = {
["ENABLED"] = true,
},
["CHATBUTTONFRAME7"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME2"] = {
["ENABLED"] = false,
},
["TARGETOFTARGETFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME3"] = {
["ENABLED"] = false,
},
["QUESTITEMSANCHOR"] = {
["ENABLED"] = false,
},
["ACTIONBAR3"] = {
["ENABLED"] = false,
},
["FRAMESKEYSCALE"] = {
["ENABLED"] = false,
},
["QUESTTIMERFRAME"] = {
["ENABLED"] = false,
},
["ACTIONBARS"] = {
},
["FOCUSFRAMESPELLBAR"] = {
["ENABLED"] = false,
},
["TARGETOFFOCUSFRAME"] = {
["ENABLED"] = false,
},
["BOSSBANNER"] = {
["ENABLED"] = false,
},
["LEAVEVEHICLE"] = {
["ENABLED"] = false,
},
["GROUPLOOTCONTAINER"] = {
["ENABLED"] = false,
},
["STATICPOPUP"] = {
["ENABLED"] = false,
},
["STANCEBARANCHOR"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME5"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME6"] = {
["ENABLED"] = false,
},
["FOCUSFRAMETOTDEBUFFMOVER"] = {
["ENABLED"] = false,
},
["TargetFrameNumericalThreat"] = {
["ENABLED"] = false,
},
["ACTIONBAR8"] = {
["ENABLED"] = false,
},
["MOVESMALLBAGS"] = {
["ENABLED"] = false,
},
["ENDCAPS"] = {
["ENABLED"] = false,
},
["BATTLEFIELDMAPFRAME"] = {
["ENABLED"] = false,
},
["COMBOFRAME"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME4"] = {
["ENABLED"] = false,
},
["CHATTAB"] = {
["ENABLED"] = false,
},
["CHAT1"] = {
["ENABLED"] = false,
},
["TARGETFRAMETOTBUFFMOVER"] = {
["ENABLED"] = false,
},
["EXTRAABILITYCONTAINER"] = {
["ENABLED"] = false,
},
["QUESTTRACKER"] = {
["ENABLED"] = false,
},
["FOCUSFRAMETOTBUFFMOVER"] = {
["ENABLED"] = false,
},
["UtilityCooldownViewer"] = {
["ENABLED"] = false,
},
["TOTEMFRAME"] = {
["ENABLED"] = false,
},
["ACTIONBAR6"] = {
["ENABLED"] = false,
},
["CHAT8"] = {
["ENABLED"] = false,
},
["CHAT6"] = {
["ENABLED"] = false,
},
["SPELLACTIVATIONOVERLAYFRAME"] = {
["ENABLED"] = false,
},
["PETBAR"] = {
["ENABLED"] = false,
},
["GHOSTFRAME"] = {
["ENABLED"] = false,
},
["ACTIONBAR5"] = {
["ENABLED"] = false,
},
["MainStatusTrackingBarContainer"] = {
["ENABLED"] = false,
},
["PLAYERLEVELTEXT"] = {
["ENABLED"] = false,
},
["ROLEPOLLPOPUP"] = {
["ENABLED"] = false,
},
["SAVEFRAMEPOSITION"] = {
["ENABLED"] = true,
},
["CHATBUTTONFRAME1"] = {
["ENABLED"] = false,
},
["COMPACTARENAFRAME"] = {
["ENABLED"] = false,
},
["UIERRORSFRAME"] = {
["ENABLED"] = false,
},
["ExpansionLandingPageMinimapButton"] = {
["ENABLED"] = false,
},
["ACTIONBAR4"] = {
["ENABLED"] = false,
},
["LOCKWINDOWS"] = {
["ENABLED"] = false,
},
["MALOCK"] = {
["ENABLED"] = false,
},
["UIWIDGETBELOWMINIMAP"] = {
["ENABLED"] = false,
},
["MAFPSFrame"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME10"] = {
["ENABLED"] = false,
},
["MIRRORTIMER1"] = {
["ENABLED"] = false,
},
["POWERBAR"] = {
["ENABLED"] = false,
},
["TARGETFRAMEBUFFMOVER"] = {
["ENABLED"] = false,
},
["SCALELOOTFRAME"] = {
["ENABLED"] = false,
},
["GAMETOOLTIP_ONCURSOR_NOTINCOMBAT"] = {
["ENABLED"] = false,
},
["PARTYMEMBERFRAMES"] = {
["ENABLED"] = false,
},
["CHAT5"] = {
["ENABLED"] = false,
},
["CHATQUICKJOIN"] = {
["ENABLED"] = false,
},
["EventToastManagerFrame"] = {
["ENABLED"] = false,
},
["CHAT10"] = {
["ENABLED"] = false,
},
["BNToastFrame"] = {
["ENABLED"] = false,
},
["HIDEHIDDENFRAMES"] = {
["ENABLED"] = false,
},
["ACTIONBAR7"] = {
["ENABLED"] = false,
},
["DISABLEMOVEMENT"] = {
["ENABLED"] = false,
},
["TARGETFRAME"] = {
["ENABLED"] = false,
},
["FRAMESKEYRESET"] = {
["ENABLED"] = false,
},
["ALERTFRAME"] = {
["ENABLED"] = false,
},
["BuffBarCooldownViewer"] = {
["ENABLED"] = false,
},
["ZONEABILITYFRAME"] = {
["ENABLED"] = false,
},
["BLIZZARDACTIONBUTTONSART"] = {
["ENABLED"] = false,
},
["CLAMPWINDOWTOSCREEN"] = {
["ENABLED"] = true,
},
["MOVEFRAMES"] = {
["ENABLED"] = true,
},
["CHATBUTTONFRAME8"] = {
["ENABLED"] = false,
},
["CASTINGBAR"] = {
["ENABLED"] = false,
},
["COMPACTRAIDFRAMECONTAINER"] = {
["ENABLED"] = false,
},
["SNAPTOELEMENTS"] = {
["ENABLED"] = true,
},
["CHAT3"] = {
["ENABLED"] = false,
},
["ACTIONBAR2"] = {
["ENABLED"] = false,
},
["FOCUSFRAME"] = {
["ENABLED"] = false,
},
["QUEUESTATUSFRAME"] = {
["ENABLED"] = false,
},
["SAVEFRAMESCALE"] = {
["ENABLED"] = true,
},
["BUFFS"] = {
["ENABLED"] = false,
},
["CHATEDITBOX"] = {
["ENABLED"] = false,
},
["ARENAENEMYFRAMESCONTAINER"] = {
["ENABLED"] = false,
},
["CHAT4"] = {
["ENABLED"] = false,
},
["GAMETOOLTIP_ONCURSOR"] = {
["ENABLED"] = false,
},
["SecondaryStatusTrackingBarContainer"] = {
["ENABLED"] = false,
},
["PARTYFRAME"] = {
["ENABLED"] = false,
},
["COMPACTRAIDFRAMEMANAGER"] = {
["ENABLED"] = false,
},
["PLAYERFRAME"] = {
["ENABLED"] = false,
},
["CHAT2"] = {
["ENABLED"] = false,
},
["FRAMESKEYDRAG"] = {
["ENABLED"] = false,
},
["MINIMAPFLAG"] = {
["ENABLED"] = false,
},
["TICKETSTATUSFRAME"] = {
["ENABLED"] = false,
},
["DEBUFFS"] = {
["ENABLED"] = false,
},
["READYCHECKLISTENERFRAME"] = {
["ENABLED"] = false,
},
["UIWIDGETPOWERBAR"] = {
["ENABLED"] = false,
},
["QUEUESTATUSBUTTON"] = {
["ENABLED"] = false,
},
["TARGETFRAMEDEBUFFMOVER"] = {
["ENABLED"] = false,
},
["OVERRIDEACTIONBAR"] = {
["ENABLED"] = false,
},
["ENCOUNTERBAR"] = {
["ENABLED"] = false,
},
["CHAT9"] = {
["ENABLED"] = false,
},
["FOCUSFRAMEDEBUFFMOVER"] = {
["ENABLED"] = false,
},
["BuffIconCooldownViewer"] = {
["ENABLED"] = false,
},
["MAPROFILES"] = {
["ENABLED"] = false,
},
["MOVELOOTFRAME"] = {
["ENABLED"] = false,
},
["OBJECTIVETRACKERBONUSBANNERFRAME"] = {
["ENABLED"] = false,
},
["PETFRAMEHAPPINESS"] = {
["ENABLED"] = false,
},
["CHATBUTTONFRAME9"] = {
["ENABLED"] = false,
},
["ACTIONBAR1"] = {
["ENABLED"] = false,
},
["ZONETEXTFRAME"] = {
["ENABLED"] = false,
},
["POSSESSBAR"] = {
["ENABLED"] = false,
},
["MAPETFRAME"] = {
["ENABLED"] = false,
},
["CHAT7"] = {
["ENABLED"] = false,
},
["TARGETFRAMETOTDEBUFFMOVER"] = {
["ENABLED"] = false,
},
["EssentialCooldownViewer"] = {
["ENABLED"] = false,
},
},
},
["FRAMES"] = {
["POINTS"] = {
["ProfessionsFrame"] = {
["AN"] = "BOTTOMLEFT",
["PX"] = 54,
["PY"] = 475,
["RE"] = "BOTTOMLEFT",
},
["ClassTrainerFrame"] = {
},
["AddonList"] = {
},
["CommunitiesFrame"] = {
},
["GameMenuFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 359,
["PX"] = 924,
["RE"] = "BOTTOMLEFT",
},
["SettingsPanel"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 96,
["RE"] = "BOTTOMLEFT",
["PX"] = 291,
},
["CharacterFrame"] = {
},
["MailFrame"] = {
},
["QuickKeybindFrame"] = {
},
["GossipFrame"] = {
},
["MerchantFrame"] = {
},
["WorldMapFrame"] = {
},
["PlayerSpellsFrame"] = {
["AN"] = "BOTTOMLEFT",
["PY"] = 346,
["RE"] = "BOTTOMLEFT",
["PX"] = 16,
},
["QuestFrame"] = {
},
["ItemRefTooltip"] = {
},
["StaticPopup1"] = {
},
["CollectionsJournal"] = {
},
},
["SIZES"] = {
["ProfessionsFrame"] = {
},
["ClassTrainerFrame"] = {
},
["AddonList"] = {
},
["CommunitiesFrame"] = {
},
["GameMenuFrame"] = {
},
["SettingsPanel"] = {
["SCALE"] = 1.008,
},
["CharacterFrame"] = {
},
["MailFrame"] = {
},
["QuickKeybindFrame"] = {
},
["GossipFrame"] = {
},
["MerchantFrame"] = {
},
["WorldMapFrame"] = {
},
["PlayerSpellsFrame"] = {
},
["QuestFrame"] = {
},
["ItemRefTooltip"] = {
},
["StaticPopup1"] = {
},
["CollectionsJournal"] = {
["SCALE"] = 0.991,
},
},
},
},
},
}
